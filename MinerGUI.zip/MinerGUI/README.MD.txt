HTMLCoin-Windows-Miner Version 0.0.8

htmlcoin-cli Version 2.0.1.0

Its only a GUI (grafic user interface) for the official (https://github.com/HTMLCOIN/HTMLCOIN/releases) htmlcoin-cli.exe. You must have install a HTML-Wallet, but it can be empty (the App will say it to you).

The WindowsMiner.exe start the GUI for Mining HTML Coins. For each CPU/Core you can start on Mining Tread. If you have 2 CPUs with 2 Cores you can start 3 Treads (one for you to work).

Its a very young ALPHA Version and i must put in some more work...

Thinks to do:

    Show a report if we have found a Block.
    Merge Bugs you tell me.....

You can reach me under BMP@gmx.de or an Telegram under https://t.me/HTMLmining (Marcus Berger)

Download: https://github.com/BMP0007/HTMLCoin-Windows-Miner/raw/master/MinerGUI.zip
I have open the SourceCode here.

Everybudy can take a look into the Source Code here. The MinerWindows is the Main App (GUI) and the Miner is the worker. It is written in AHK and you can easy compile it self with the Compiler from: https://autohotkey.com/

I realy hope that i get some Donation HTMLS under: HdTjPZuBtx6BTC6yKwkFPe1qtjyiizFWob